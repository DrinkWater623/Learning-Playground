﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops
{
    internal class ProgramStart
    {
    }
}
*/
using Loops;

if ( StringInput.GetInput() )
    Console.WriteLine("String Input Test Taken");
else
    Console.WriteLine("String Input Test ByPassed");


if ( NumberInput.GetInput() )
    Console.WriteLine("Number Input Test Taken");
else
    Console.WriteLine("Number Input Test ByPassed");
